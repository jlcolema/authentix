<?php
/**
 * Displays a condition logic HTML block
 */

defined( 'ABSPATH' ) || exit;

self::conditional_groups_display( $group_block, $prefix );
