<?php

namespace DeliciousBrains\WPMDB\Pro\Migration;

/**
 * Deprecated class for pre-2.0 addons!
 */
class Connection
{
}
