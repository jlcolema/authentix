<?php


namespace DeliciousBrains\WPMDB\Pro\Migration\Tables;


class Local
{

}
